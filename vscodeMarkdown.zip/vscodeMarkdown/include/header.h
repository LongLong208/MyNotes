#ifndef HEADER_H
#define HEADER_H

#include <bits/stdc++.h>
#include "customMethod.h"

// 可以在这里添加需要包含的头文件

#endif
